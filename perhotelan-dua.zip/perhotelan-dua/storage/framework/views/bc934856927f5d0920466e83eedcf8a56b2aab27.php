

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
        <form method="POST" action="/update">
            <?php echo csrf_field(); ?>
        <div class="mb-3">
        <input type="hidden" class="form-control" name="id" value="<?php echo e($kamar->id); ?>">
          <label type="hidden" for="exampleInputEmail1">Nama Kamar</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="nama_kamar" aria-describedby="emailHelp" value="<?php echo e($kamar->nama_kamar); ?>">
        </div>
            <button type="submit" class="btn btn-primary float-end">Update</button>
        </form>
        </div>
    </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan-dua\resources\views/tampilan/edit-kamar.blade.php ENDPATH**/ ?>