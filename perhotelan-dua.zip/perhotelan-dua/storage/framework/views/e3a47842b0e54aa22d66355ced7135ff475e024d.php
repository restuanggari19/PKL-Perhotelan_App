

<?php $__env->startSection('content'); ?>
<div class=" fs-1 text-center">HOME</div>
<br>
<div class="row">
  <div class="col-sm-3">
    <div class="card bg-primary ">
      <div class="card-body ">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Tamu Pesanan</h5>
        <br>
        <h1 class="text-white fs-4"><?php echo e($tamu); ?></h1>
      </div>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card bg-success">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Kamar Pesanan</h5>
        <br>
        <h1 class="text-white fs-4"><?php echo e($kamar); ?></h1>
      </div>
    </div>
  </div>
</div>
  <div class="col-sm-3">
    <div class="card bg-warning">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total fasilitas Pesanan</h5>
        <br>
        <h1 class="text-white fs-4"><?php echo e($fasilitas); ?></h1>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card bg-secondary">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Data Booking</h5>
        <br>
        <h1 class="text-white fs-4"><?php echo e($booking); ?></h1>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan-dua\resources\views/tampilan/dashboard.blade.php ENDPATH**/ ?>