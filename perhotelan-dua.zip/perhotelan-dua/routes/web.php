<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\FasilitasController;
use App\Http\Controllers\Admin\KamarController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//dashboard
Route::get('/home', [App\Http\Controllers\Admin\DashboardController::class, 'index']);

//tamu
Route::get('/tamu', [App\Http\Controllers\Admin\TamuController::class, 'index']);
Route::get('/datatable/tamu', [App\Http\Controllers\Admin\TamuController::class, 'datatableTamu']);
Route::get('/edit-tamu/{id}', [App\Http\Controllers\Admin\TamuController::class, 'editTamu']);
Route::post('/update', [App\Http\Controllers\Admin\TamuController::class, 'updateTamu']);

//kamar
Route::get('/kamar', [App\Http\Controllers\Admin\KamarController::class, 'index']);
Route::get('/datatable/kamar', [App\Http\Controllers\Admin\KamarController::class, 'datatableKamar']);
Route::get('/form-kamar', [App\Http\Controllers\Admin\KamarController::class, 'create']);
Route::post('/store-kamar', [App\Http\Controllers\Admin\KamarController::class, 'storeKamar']);
Route::get('/edit-kamar/{id}', [App\Http\Controllers\Admin\KamarController::class, 'editKamar']);
Route::post('/update', [App\Http\Controllers\Admin\KamarController::class, 'updateKamar']);

//fasilitas
Route::get('/fasilitas', [App\Http\Controllers\Admin\FasilitasController::class, 'index']);
Route::get('/datatable/fasilitas', [App\Http\Controllers\Admin\FasilitasController::class, 'datatableFasilitas']);
Route::get('/form-fasilitas', [App\Http\Controllers\Admin\FasilitasController::class, 'create']);
Route::post('/store-fasilitas', [App\Http\Controllers\Admin\FasilitasController::class, 'storeFasilitas']);
Route::get('/edit-fasilitas/{id}', [App\Http\Controllers\Admin\FasilitasController::class, 'editFasilitas']);
Route::post('/update', [App\Http\Controllers\Admin\FasilitasController::class, 'updateFasilitas']);

//booking
Route::get('/booking', [App\Http\Controllers\Admin\BookingController::class, 'index']);
Route::get('/datatable/booking', [App\Http\Controllers\Admin\BookingController::class, 'datatableBooking']);

//pesan
Route::get('/', [App\Http\Controllers\Admin\PesanController::class, 'index']);
Route::post('/store-pesan', [App\Http\Controllers\Admin\PesanController::class, 'storePesan']);
Route::get('/form-sukses', [App\Http\Controllers\Admin\PesanController::class, 'formPesan']);







