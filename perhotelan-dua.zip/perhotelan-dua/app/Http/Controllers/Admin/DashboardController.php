<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Kamar;
use Illuminate\Http\Request;
use App\Models\Tamu;
use App\Models\Fasilitas;
use App\Models\Booking;

class DashboardController extends Controller
{
    public function index()
    {
        $tamu = TAMU::where('id', '!=', 0)->count();
        $kamar = Kamar::where('is_booked', 0)->count();
        $fasilitas = Fasilitas::where('id', '!=', 0)->count();
        $booking = Booking::where('id', '!=', 0)->count(); 

        return view('tampilan.dashboard', compact('tamu', 'kamar', 'fasilitas', 'booking'));
    }

}
