<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Booking;

class BookingController extends Controller
{
    public function index()
    {
        return view('tampilan.booking');
    }

    public function datatableBooking()
    {
        $data = [];
        $booking = Booking::get();
        foreach ($booking as $item) {
            $data[] = [
                $item->id,
                $item->tamu->nama_tamu,
                $item->kamar->nama_kamar,
                $item->fasilitas->nama_fasilitas,
                $item->tanggal_booking,
                '<a href="/edit-booking/'.$item->id.'" class="btn btn-success">Check-In</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Check-Out</a>'
            ];

        }

        return [
            'data' => $data
        ];
    }
}
