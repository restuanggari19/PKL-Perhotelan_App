<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Kamar;

class KamarController extends Controller
{
    public function index()
    {
        return view('tampilan.kamar');
    }

    public function create()
    {
        return view('tampilan.form-kamar');
    }

    public function storeKamar(Request $request)
    {
        $status = Kamar::storeKamar($request);
        if($status) return redirect('/kamar');
        else return redirect('/kamar');
    }

    public function datatableKamar()
    {
        $data = [];
        $kamar = Kamar::get();
        foreach ($kamar as $item) {
            $data[] = [
                $item->id,
                $item->nama_kamar,
                '<a href="/edit-kamar/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
            ];

        }

        return [
            'data' => $data
        ];
    }

    public function editKamar(Request $request, $id)
    {
        $data['kamar'] = Kamar::find($id);

        return view('tampilan.edit-kamar', $data);
    }

    public function updateKamar(Request $request)
    {
        $status = Kamar::updateKamar($request);
        if ($status) return redirect('/kamar');
        else return redirect('/edit-kamar');
    }
}
