<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Kamar;
use App\Models\Fasilitas;
use App\Models\Booking;
use App\Models\Tamu;
use Carbon\Carbon;

class PesanController extends Controller
{
    public function index()
    {
        $kamar = Kamar::where('is_booked', 0)->get();
        $fasilitas = Fasilitas::all();
        return view('tampilan.form-pesan', compact('kamar', 'fasilitas'));
    }

    public function storePesan(Request $request)
    {
        $kamar          = Kamar::find($request->kamar_id);
        $fasilitas      = Fasilitas::find($request->fasilitas_id);
        $hargakamar     = Kamar::hargaKamar($kamar->nama_kamar);
        $datetime       = Carbon::now();
        $tamu           = Tamu::create([
            'nama_tamu'     => $request->nama_tamu,
            'jenis_kelamin' => $request->jenis_kelamin,
            'no_telepon'    => $request->no_telepon,
            'alamat'        => $request->alamat,
        ]);
        $total_harga    = $hargakamar + $fasilitas->harga;

        $store = Booking::create([
            'tamu_id'       => $tamu->id,
            'kamar_id'      => $kamar->id,
            'fasilitas_id'  => $fasilitas->id,
            'tanggal_booking' => $datetime->format('Y-m-d'),
            'total_harga'   => $total_harga,
        ]);

        $setIsBooked = Kamar::where('id', $kamar->id)->update([
            'is_booked' => 1,
        ]);

        return redirect('/form-sukses')->with('success', 'Pemesanan Kamar Berhasil');
    }

    public function formPesan()
    {
        return view('Tampilan.form-sukses');
    }
}
