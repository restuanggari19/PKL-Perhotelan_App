<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tamu;

class TamuController extends Controller
{
    public function index()
    {
        return view('tampilan.tamu');
    }

    public function datatableTamu() 
    {
        $data = [];
        $tamu = Tamu::get();
        foreach ($tamu as $item) {
            $data[] = [
                $item->id,
                $item->nama_tamu,
                $item->jenis_kelamin,
                $item->alamat,
                $item->no_telepon,
                '<a href="/edit-tamu/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
            ];

        }

        return [
            'data' => $data
        ];
    }

    public function editTamu(Request $request, $id)
    {
        $data['tamu'] = Tamu::find($id);

        return view('tampilan.edit-tamu', $data);
    }

    public function updateTamu(Request $request)
    {
        $status = Tamu::updateTamu($request);
        if ($status) return redirect('/tamu');
        else return redirect('/edit-tamu');
    }
}
