<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kamar extends Model
{
    use HasFactory;

    protected $fillable =[
        'nama_kamar',
    ];

    public function scopeStoreKamar($query, $request)
    {
        $status = $query->create([
            'nama_kamar' => $request->nama_kamar,
        ]);

        if($status) return false;

        return true;
    }

    public function scopeHargaKamar($query, $nama_kamar)
    {
        $harga = 200000;

        if($nama_kamar == 'Deluxe Room'){
            $harga = 500000;
        } else if($nama_kamar == 'Superior Room') {
            $harga = 300000;
        }

        return $harga;
    }

    public function scopeUpdateKamar($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_kamar' => $request->nama_kamar,
        ]);
        if(!$status) return false;
        return true;
    }
 
}
