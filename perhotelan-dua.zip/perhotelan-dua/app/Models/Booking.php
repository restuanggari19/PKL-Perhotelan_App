<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'tamu_id',
        'kamar_id',
        'fasilitas_id',
        'tanggal_booking',
        'total_harga'
    ];

    public function kamar()
    {
        return $this->belongsTo(Kamar::class);
    }

    public function tamu()
    {
        return $this->belongsTo(Tamu::class);
    }

    public function fasilitas()
    {
        return $this->belongsTo(Fasilitas::class);
    }
}
