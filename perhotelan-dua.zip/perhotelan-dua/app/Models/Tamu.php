<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tamu extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_tamu',
        'jenis_kelamin',
        'no_telepon',
        'alamat'
    ];

    public function scopeUpdateTamu($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_tamu' => $request->nama_tamu,
            'jenis_kelamin' => $request->jenis_kelamin,
            'no_telepon' => $request->no_telepon,
            'alamat' => $request->alamat
        ]);
        if ($status) return true;
        else return false;
    }
}
