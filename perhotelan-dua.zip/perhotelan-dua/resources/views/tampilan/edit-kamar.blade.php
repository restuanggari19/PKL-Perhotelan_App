@extends('layout.admin')

@section('content')
    <div class="card">
        <div class="card-body">
        <form method="POST" action="/update">
            @csrf
        <div class="mb-3">
        <input type="hidden" class="form-control" name="id" value="{{ $kamar->id }}">
          <label type="hidden" for="exampleInputEmail1">Nama Kamar</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="nama_kamar" aria-describedby="emailHelp" value="{{ $kamar->nama_kamar }}">
        </div>
            <button type="submit" class="btn btn-primary float-end">Update</button>
        </form>
        </div>
    </div>  
@endsection