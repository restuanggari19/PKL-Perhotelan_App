@extends('layout.admin')

@section('content')
<div class=" fs-1 text-center">HOME</div>
<br>
<div class="row">
  <div class="col-sm-3">
    <div class="card bg-primary ">
      <div class="card-body ">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Tamu Pesanan</h5>
        <br>
        <h1 class="text-white fs-4">{{ $tamu }}</h1>
      </div>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card bg-success">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Kamar Pesanan</h5>
        <br>
        <h1 class="text-white fs-4">{{ $kamar }}</h1>
      </div>
    </div>
  </div>
</div>
  <div class="col-sm-3">
    <div class="card bg-warning">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total fasilitas Pesanan</h5>
        <br>
        <h1 class="text-white fs-4">{{ $fasilitas }}</h1>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card bg-secondary">
      <div class="card-body">
      <div class="text-center">
        <h5 class="card-title text-white fs-3">Total Data Booking</h5>
        <br>
        <h1 class="text-white fs-4">{{ $booking }}</h1>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection