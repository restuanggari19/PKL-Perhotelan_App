@extends('layout.admin')

@section('content')
    <div class="card">
        <div class="card-body">
        <form method="POST" action="/update">
            @csrf
        <div class="mb-3">
        <input type="hidden" class="form-control" name="id" value="{{ $fasilitas->id }}">
          <label type="hidden" for="exampleInputEmail1">Nama Fasilitas</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="nama_fasilitas" aria-describedby="emailHelp" value="{{ $fasilitas->nama_fasilitas }}">
        </div>
        <div class="mb-3">
        <input type="hidden" class="form-control" name="id" value="{{ $fasilitas->id }}">
          <label type="hidden" for="exampleInputEmail1">Harga</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="harga" aria-describedby="emailHelp" value="{{ $fasilitas->harga }}">
        </div>
            <button type="submit" class="btn btn-primary float-end">Update</button>
        </form>
        </div>
    </div>  
@endsection